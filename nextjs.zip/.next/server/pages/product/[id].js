"use strict";
(() => {
var exports = {};
exports.id = 360;
exports.ids = [360];
exports.modules = {

/***/ 2999:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Color = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            className: "colors ps-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Color);


/***/ }),

/***/ 3259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-image-zoom"
const external_react_image_zoom_namespaceObject = require("react-image-zoom");
var external_react_image_zoom_default = /*#__PURE__*/__webpack_require__.n(external_react_image_zoom_namespaceObject);
;// CONCATENATED MODULE: external "react-icons/tb"
const tb_namespaceObject = require("react-icons/tb");
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./component/common/BreadCrumb.js
var BreadCrumb = __webpack_require__(1703);
// EXTERNAL MODULE: ./component/styled/Container.js
var Container = __webpack_require__(7099);
// EXTERNAL MODULE: ./component/styled/Color.js
var Color = __webpack_require__(2999);
// EXTERNAL MODULE: ./component/ProductCard.js
var ProductCard = __webpack_require__(5450);
// EXTERNAL MODULE: external "react-rating-stars-component"
var external_react_rating_stars_component_ = __webpack_require__(9906);
var external_react_rating_stars_component_default = /*#__PURE__*/__webpack_require__.n(external_react_rating_stars_component_);
;// CONCATENATED MODULE: ./pages/product/[id].js











const SingleProduct = (props)=>{
    const { productProps  } = props;
    const [orderedProduct, setorderedProduct] = (0,external_react_.useState)(true);
    const copyToClipboard = (text)=>{
        alert("text", text);
        var textField = document.createElement("textarea");
        textField.innerText = text;
        document.body.appendChild(textField);
        textField.select();
        document.execCommand("copy");
        textField.remove();
    };
    const closeModal = ()=>{};
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BreadCrumb/* default */.Z, {
                title: "Product Name"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Container/* default */.Z, {
                class1: "main-product-wrapper py-5 home-wrapper-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "main-product-image",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_zoom_default()), {
                                            ...productProps
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "other-product-images d-flex flex-wrap gap-15",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "main-product-details",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "border-bottom",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "title",
                                            children: "Kids Headphones Bulk 10 Pack Multi Colored For Students"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "border-bottom py-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "price",
                                                children: "$ 100"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex align-items-center gap-10",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_rating_stars_component_default()), {
                                                        count: 5,
                                                        size: 24,
                                                        value: 4,
                                                        edit: false,
                                                        activeColor: "#ffd700"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mb-0 t-review",
                                                        children: "( 2 Reviews )"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "review-btn",
                                                href: "#review",
                                                children: "Write a Review"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " py-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Type :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "product-data",
                                                        children: "Watch"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Brand :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "product-data",
                                                        children: "Havells"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Category :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "product-data",
                                                        children: "Watch"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Tags :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "product-data",
                                                        children: "Watch"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Availablity :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "product-data",
                                                        children: "In Stock"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 flex-column mt-2 mb-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Size :"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "d-flex flex-wrap gap-15",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "badge border border-1 bg-white text-dark border-secondary",
                                                                children: "S"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "badge border border-1 bg-white text-dark border-secondary",
                                                                children: "M"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "badge border border-1 bg-white text-dark border-secondary",
                                                                children: "XL"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "badge border border-1 bg-white text-dark border-secondary",
                                                                children: "XXL"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 flex-column mt-2 mb-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Color :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Color/* default */.Z, {})
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex align-items-center gap-15 flex-row mt-2 mb-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Quantity :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "number",
                                                            name: "",
                                                            min: 1,
                                                            max: 10,
                                                            className: "form-control",
                                                            style: {
                                                                width: "70px"
                                                            },
                                                            id: ""
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "d-flex align-items-center gap-30 ms-5",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                className: "button border-0",
                                                                "data-bs-toggle": "modal",
                                                                "data-bs-target": "#staticBackdrop",
                                                                type: "button",
                                                                children: "Add to Cart"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                className: "button signup",
                                                                children: "Buy It Now"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex align-items-center gap-15",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                            href: "",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(tb_namespaceObject.TbGitCompare, {
                                                                    className: "fs-5 me-2"
                                                                }),
                                                                " Add to Compare"
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                            href: "",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineHeart, {
                                                                    className: "fs-5 me-2"
                                                                }),
                                                                " Add to Wishlist"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 flex-column my-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Shipping & Returns :"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "product-data",
                                                        children: [
                                                            "Free shipping and returns available on all orders! ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            " We ship all US domestic orders within",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                                children: "5-10 business days!"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "d-flex gap-10 align-items-center my-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "product-heading",
                                                        children: "Product Link:"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "",
                                                        onClick: ()=>{
                                                            copyToClipboard("https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg");
                                                        },
                                                        children: "Copy Product Link"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Container/* default */.Z, {
                class1: "description-wrapper py-5 home-wrapper-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-12",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                children: "Description"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-white p-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur nisi similique illum aut perferendis voluptas, quisquam obcaecati qui nobis officia. Voluptatibus in harum deleniti labore maxime officia esse eos? Repellat?"
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Container/* default */.Z, {
                class1: "reviews-wrapper home-wrapper-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-12",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                id: "review",
                                children: "Reviews"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "review-inner-wrapper",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "review-head d-flex justify-content-between align-items-end",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        className: "mb-2",
                                                        children: "Customer Reviews"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "d-flex align-items-center gap-10",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_rating_stars_component_default()), {
                                                                count: 5,
                                                                size: 24,
                                                                value: 4,
                                                                edit: false,
                                                                activeColor: "#ffd700"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "mb-0",
                                                                children: "Based on 2 Reviews"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            orderedProduct && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "text-dark text-decoration-underline",
                                                    href: "",
                                                    children: "Write a Review"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "review-form py-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Write a Review"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                action: "",
                                                className: "d-flex flex-column gap-15",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_rating_stars_component_default()), {
                                                            count: 5,
                                                            size: 24,
                                                            value: 4,
                                                            edit: true,
                                                            activeColor: "#ffd700"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                            name: "",
                                                            id: "",
                                                            className: "w-100 form-control",
                                                            cols: "30",
                                                            rows: "4",
                                                            placeholder: "Comments"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "d-flex justify-content-end",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "button border-0",
                                                            children: "Submit Review"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "reviews mt-4",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "review",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex gap-10 align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                            className: "mb-0",
                                                            children: "Navdeep"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((external_react_rating_stars_component_default()), {
                                                            count: 5,
                                                            size: 24,
                                                            value: 4,
                                                            edit: false,
                                                            activeColor: "#ffd700"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mt-3",
                                                    children: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur fugit ut excepturi quos. Id reprehenderit voluptatem placeat consequatur suscipit ex. Accusamus dolore quisquam deserunt voluptate, sit magni perspiciatis quas iste?"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container/* default */.Z, {
                class1: "popular-wrapper py-5 home-wrapper-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "section-heading",
                                children: "Our Popular Products"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ProductCard/* default */.Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal fade",
                id: "staticBackdrop",
                "data-bs-backdrop": "static",
                "data-bs-keyboard": "false",
                tabIndex: "-1",
                "aria-labelledby": "staticBackdropLabel",
                "aria-hidden": "true",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "modal-dialog modal-dialog-centered ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal-header py-0 border-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "button",
                                    className: "btn-close",
                                    "data-bs-dismiss": "modal",
                                    "aria-label": "Close"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal-body py-0",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex align-items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex-grow-1 w-50",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/images/watch.jpg",
                                                className: "img-fluid",
                                                alt: "product imgae"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "d-flex flex-column flex-grow-1 w-50",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "mb-3",
                                                    children: "Apple Watch"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mb-1",
                                                    children: "Quantity: asgfd"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mb-1",
                                                    children: "Color: asgfd"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "mb-1",
                                                    children: "Size: asgfd"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-footer border-0 py-0 justify-content-center gap-30",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "button",
                                        "data-bs-dismiss": "modal",
                                        children: "View My Cart"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "button signup",
                                        children: "Checkout"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "d-flex justify-content-center py-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "text-dark",
                                    href: "/product",
                                    onClick: ()=>{
                                        closeModal();
                                    },
                                    children: "Continue To Shopping"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const _id_ = (SingleProduct);
async function getServerSideProps(context) {
    return {
        props: {
            productProps: {
                width: 594,
                height: 600,
                zoomWidth: 600,
                img: "https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?cs=srgb&dl=pexels-fernando-arcos-190819.jpg&fm=jpg"
            }
        }
    };
}


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 9906:
/***/ ((module) => {

module.exports = require("react-rating-stars-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,703,628], () => (__webpack_exec__(3259)));
module.exports = __webpack_exports__;

})();