"use strict";
exports.id = 544;
exports.ids = [544];
exports.modules = {

/***/ 9661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
class ApiUrl {
    static MainUrl = "https://demo.royalscripts.com/genius-shop/api";
    static getsliders = `${this.MainUrl}/front/sliders`;
    static getBlogs = `${this.MainUrl}/front/blogs`;
    static getCategories = `${this.MainUrl}/front/categories`;
    static getService = `${this.MainUrl}/front/services`;
    static getProducts = `${this.MainUrl}/front/products`;
    static getSingleCategory = (category)=>`${this.MainUrl}/front/?category=${category}`;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApiUrl);


/***/ }),

/***/ 4544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BlogContext),
  "s": () => (/* binding */ BlogContextProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./lib/Api/ApiUrl.js
var ApiUrl = __webpack_require__(9661);
;// CONCATENATED MODULE: ./lib/reducer/BlogReducer.jsx
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case "GET_BLOGS":
            return {
                ...state,
                blogs: action.payload,
                latest_blogs: action.payload.slice(-0, 4)
            };
    }
};
/* harmony default export */ const BlogReducer = (reducer);

;// CONCATENATED MODULE: ./lib/context/BlogContext.jsx




const BlogContext = /*#__PURE__*/ (0,external_react_.createContext)();
const BlogContext_initialState = {
    blogs: [],
    latest_blogs: []
};
const BlogContextProvider = ({ children  })=>{
    const [state, dispatch] = (0,external_react_.useReducer)(BlogReducer, BlogContext_initialState);
    (0,external_react_.useEffect)(()=>{
        getBlogs();
    }, []);
    const getBlogs = async ()=>{
        const response = await fetch(ApiUrl/* default.getBlogs */.Z.getBlogs);
        const data = await response.json();
        dispatch({
            type: "GET_BLOGS",
            payload: data.data
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(BlogContext.Provider, {
        value: state,
        children: children
    });
};



/***/ })

};
;