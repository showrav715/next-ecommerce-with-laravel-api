"use strict";
exports.id = 480;
exports.ids = [480];
exports.modules = {

/***/ 7049:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ CategoryContext),
/* harmony export */   "h": () => (/* binding */ CategoryContextProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Api_ApiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9661);
/* harmony import */ var _reducer_CategoryReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2901);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const CategoryContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)();
const initialState = {
    categories: [],
    category: {},
    error: null
};
const CategoryContextProvider = ({ children  })=>{
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useReducer)(_reducer_CategoryReducer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, initialState);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getCategories();
    }, []);
    // get all categories
    const getCategories = async ()=>{
        try {
            const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Api_ApiUrl__WEBPACK_IMPORTED_MODULE_3__/* ["default"].getCategories */ .Z.getCategories}`);
            dispatch({
                type: "GET_CATEGORIES_SUCCESS",
                payload: response.data.data
            });
        } catch (error) {
            dispatch({
                type: "GET_CATEGORIES_ERROR",
                payload: error
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CategoryContext.Provider, {
        value: {
            ...state
        },
        children: children
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* binding */ ProductContext),
  "G": () => (/* binding */ ProductProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./lib/Api/ApiUrl.js
var ApiUrl = __webpack_require__(9661);
;// CONCATENATED MODULE: ./lib/reducer/ProductReducer.jsx
const Reducer = (state, action)=>{
    switch(action.type){
        case "LOADING":
            return {
                ...state,
                loading: true
            };
        case "STORE_ITEMS":
            const featuredProducts = action.payload.slice(0, 8);
            const popular_products = action.payload.slice(0, 8);
            const special_offers = action.payload.slice(8, 12);
            return {
                ...state,
                products: action.payload,
                loading: false,
                featuredProducts,
                special_offers,
                popular_products
            };
        case "ERROR":
            return {
                ...state,
                error: action.payload,
                loading: false
            };
        default:
            return state;
    }
};
/* harmony default export */ const ProductReducer = (Reducer);

;// CONCATENATED MODULE: ./lib/context/ProductContext.jsx




const ProductContext = /*#__PURE__*/ (0,external_react_.createContext)();
const ProductProvider = ({ children  })=>{
    const initsvalue = {
        products: [],
        featuredProducts: [],
        special_offers: [],
        popular_products: [],
        loading: false,
        error: ""
    };
    const [state, dispatch] = (0,external_react_.useReducer)(ProductReducer, initsvalue);
    (0,external_react_.useEffect)(()=>{
        getProducts();
    }, []);
    const getProducts = async ()=>{
        dispatch({
            type: "LOADING"
        });
        try {
            const response = await fetch(ApiUrl/* default.getProducts */.Z.getProducts);
            const data = await response.json();
            dispatch({
                type: "STORE_ITEMS",
                payload: data.data
            });
        } catch (error) {
            dispatch({
                type: "ERROR",
                payload: error
            });
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(ProductContext.Provider, {
        value: {
            ...state
        },
        children: children
    });
};



/***/ }),

/***/ 2901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const categoryReducer = (state, action)=>{
    switch(action.type){
        case "GET_CATEGORIES_SUCCESS":
            return {
                ...state,
                categories: action.payload,
                loading: false
            };
        case "GET_CATEGORIES_ERROR":
            return {
                ...state,
                error: action.payload,
                loading: false
            };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (categoryReducer);


/***/ })

};
;