const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "demo.royalscripts.com",
      },
    ],
  },
}

module.exports = nextConfig